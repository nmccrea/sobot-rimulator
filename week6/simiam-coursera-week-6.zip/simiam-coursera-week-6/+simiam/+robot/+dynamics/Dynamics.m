classdef Dynamics < handle

% Copyright (C) 2013, Georgia Tech Research Corporation
% see the LICENSE file included with this software
    
    properties
        
    end
    
    methods
        function pose_t_1 = apply_dynamics(obj, pose_t, dt)

	end
    end
    
end

